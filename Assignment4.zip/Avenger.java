import java.util.Scanner;

public class Avenger
{
    Scanner sc= new Scanner(System.in);
    int age;
    String  name,power,weapon,planet;
    


    public void getDetails()
    {   

        System.out.println("Enter age : ");
        age=sc.nextInt();

        System.out.println("Enter name : ");
        name=sc.next();
        
        System.out.println("Enter power : ");
        power=sc.next();
        
        System.out.println("Enter weapon : ");
        weapon=sc.next();

        System.out.println("Enter planet : ");
        planet=sc.next();
    }

    public void displayDetails()
    {   
        System.out.println("The name is "+name);

        System.out.println("The age is "+age);

        System.out.println("The power is "+power);

        System.out.println("The weapon is "+weapon);

        System.out.println("The planet is "+planet);

 
    }

     public static void main(String [] args)
    {
        Avenger[] avengers= new Avenger[5];
        for(int i=0; i<5;i++)
        {
            avengers[i]=new Avenger();
            avengers[i].getDetails();
        }
        
       for(int i=0; i<5;i++)
        { 
            avengers[i].displayDetails();
        }
    }
}